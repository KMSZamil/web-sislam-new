<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Seller_Entertainment extends Model
{
    use HasFactory;

    protected $table = 'seller_entertainment';
    public $timestamps = false;
}
