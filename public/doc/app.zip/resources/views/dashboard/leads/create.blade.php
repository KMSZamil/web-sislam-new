@extends('dashboard.layouts.master')
@section('content')
<!-- column -->
<h1>Leaads</h1>
<!-- /column -->
@endsection
