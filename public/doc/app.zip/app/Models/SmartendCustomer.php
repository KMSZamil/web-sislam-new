<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SmartendCustomer extends Model
{
    protected $table = 'customers';
    protected $guarded = ['id'];

}