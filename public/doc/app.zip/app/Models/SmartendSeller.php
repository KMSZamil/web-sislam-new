<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SmartendSeller extends Model
{
    protected $table = 'seller';
    protected $guarded = ['id'];

}